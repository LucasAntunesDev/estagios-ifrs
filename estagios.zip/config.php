<?php
//config.php

#Definindo as configurações de conexão ao bd como constantes
define('HOST', 'localhost'); #host
define('BASE', 'estagios');#nome do bd
define('USER', 'root');#usuário
define('PASS', '');#senha
